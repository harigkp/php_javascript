<?php 
require('main.php');
$res = $conn->getResults();
$protocol = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off' || $_SERVER['SERVER_PORT'] == 443) ? "https://" : "http://";
$domainName = $_SERVER['HTTP_HOST'].'/';
$host  = $protocol.$domainName."TEST_i/";
?>
<!doctype html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">

    <title>Test3</title>



 <script src="https://cdnjs.cloudflare.com/ajax/libs/moment.js/2.18.1/moment.js"></script>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/2.1.1/jquery.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datetimepicker/4.17.37/js/bootstrap-datetimepicker.min.js"></script>

<link href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css" rel="stylesheet">
<link href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datetimepicker/4.17.37/css/bootstrap-datetimepicker.min.css" rel="stylesheet">


  </head>

  <body class="bg-light">

    <div class="container">

<form id="test3_view" enctype="multipart/form-data" method="post" action="<?php echo $host;?>task3.php">
<div class="form-group row mb-4">
      <div class="row">
        <div class="col-md-8 order-md-1">
          <h4 class="mb-3">Test3 View </h4>
            <div class="row">
              <div class="col-md-6 mb-3">
                <label for="script_name">Script Name</label>
                <input type="text" class="form-control" name="script_name" id="script_name" placeholder="" value="" required>                
              </div>
            </div>
            <div class="row">
              <div class="col-md-6 mb-3">			  
			  
			  <div class='input-group date' id="start_time">
                <label for="start_time">Start Time</label>
                <input type="text" class="form-control" name="start_time" id="start_time_field" placeholder="" value="" required>     
			
              </div>
			  </div>
              <div class="col-md-6 mb-3">
			  <div class='input-group date' id="end_time">
                <label for="end_time">End Time </label>
                <input type="text" class="form-control" name="end_time" id="end_time" placeholder="" value="" required>

              </div>
			  </div>
            </div>
            <div class="mb-3">
              <label for="result">Result</label>
              <div class="input-group">
				<select aria-label="Default select example" name="results">
				<option value="" selected>Select Results</option>
				<?php while($row= mysqli_fetch_assoc($res)){?>
				  <option value="<?php echo $row['id'];?>"><?php echo $row['name'];?></option>
				<?php } ?>
				</select>
              </div>
            </div>

          <hr class="mb-4">
            

<div class="spinner-border text-primary" role="status" id="load" style="display:none;">
  <span class="sr-only">Loading...</span>
</div>
            <input type="hidden" name="action" value="test3submit">
			<button id="" class="btn btn-primary btn-lg btn-block" type="submit">Submit</button>
     
        </div>
      </div>
	  </div>
	  </form>
    </div>
<script type="text/javascript">
	$('#start_time').datetimepicker({
		allowInputToggle: true
	});
	$('#end_time').datetimepicker({
		allowInputToggle: true
	});	
	
$("#test3_view").submit(function(e){
	$.ajax({
		type: "POST",
		url: "<?php echo $host;?>task3.php",
		data: new FormData(this),
		contentType: false,
		processData: false,
		success: function(res){
					alert(res);
		   
		}
		
	});
});
</script>	
	
	
    
  </body>
</html>
