<?php  
/* ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL); */
@define('DB_SERVER', "localhost"); 
@define('DB_USER', "root"); 
@define('DB_PASSWORD', ""); 
@define('DB_DATABASE', "notamedia"); 
