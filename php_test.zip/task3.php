<?php
	class TableCreator{
		
		 function __construct() {
			require_once($_SERVER['DOCUMENT_ROOT'].dirname($_SERVER["PHP_SELF"]).'/conn.php');
			 $this->conn = mysqli_connect(DB_SERVER, DB_USER, DB_PASSWORD, DB_DATABASE);   
			 $protocol = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off' || $_SERVER['SERVER_PORT'] == 443) ? "https://" : "http://";
			 $domainName = $_SERVER['HTTP_HOST'].'/';
			 $this->host  = $protocol.$domainName."TEST_i/";

		}	

			function create($data){

				$script_name = mysqli_real_escape_string($this->conn, stripcslashes(SUBSTR($data['script_name'], 0, 25)));
				$start_time = date("Y-m-d h:i:s",strtotime($data['start_time']));
				$end_time= date("Y-m-d h:i:s",strtotime($data['end_time']));
				$result= $data['results'];
				$sql= "INSERT INTO test(script_name, start_time, end_time, result)
				VALUES('$script_name', '$start_time', '$end_time', '$result')"; 
				$stmt = mysqli_query($this->conn, $sql);
				header("Location: ".$this->host."test3_view.php");
			}

			function fill($username, $password){
					   //code
			}
        public function get(){
			
			
		}
		
		
	}


if(isset($_POST['action']) && $_POST['action']=="test3submit"){
$obj = new TableCreator();
$obj->create($_POST);


}



?>