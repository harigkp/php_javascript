<?php
/**
 * Create Task 1: Find all files in the /datafiles folder.
 * @param folder Path.
 * @return Display the names of these files, ordered by name.
 */
 
$folder = $_SERVER['DOCUMENT_ROOT'].dirname($_SERVER["PHP_SELF"]).'\datafiles';

// Checking if the folder exists
if (is_dir($folder)) {

    $fileNames = [];


    if ($dir = opendir($folder)) {

        while (($file = readdir($dir)) !== false) {

            if (preg_match('/^[A-Za-z0-9]+\.ixt$/', $file)) {

                $fileNames[] = $file;
            }
        }

        closedir($dir);

        sort($fileNames);

        foreach ($fileNames as $fileName) {
            echo $fileName . PHP_EOL.'<br>';
        }
    }
} else {
    echo "The specified folder does not exist.";
}
?>
