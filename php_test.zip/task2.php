<?php
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);
/**
 * Create Task 2: Create script for downloading the page https://www.wikipedia.org/, extract headings, abstracts, pictures, links from the page part with sections.
 * @param The page URL https://www.wikipedia.org/.
 * @return Extract headings, abstracts, pictures, links and save into database table wiki_sections .
 */


require_once($_SERVER['DOCUMENT_ROOT'].dirname($_SERVER["PHP_SELF"]).'/main.php');
// URL of the web page to download
$url = 'https://en.wikipedia.org/wiki/Dark_Archives';

// Initialize cURL session
$ch = curl_init($url);

// Set cURL options
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);

// Execute cURL and get the HTML content
$html = curl_exec($ch);

// Check for cURL errors
if (curl_errno($ch)) {
    echo 'cURL Error: ' . curl_error($ch);
    exit;
}

// Close cURL session
curl_close($ch);

// Create a DOMDocument to parse the HTML
$dom = new DOMDocument();
libxml_use_internal_errors(true); // Suppress HTML parsing errors

// Load the HTML content into the DOMDocument
$dom->loadHTML($html);

// Initialize arrays to store headings, abstracts, pictures, and links
$headings = [];
$abstracts = [];
$pictures = [];
$links = [];

// Extract headings, abstracts, pictures, and links
$headingsElements = $dom->getElementsByTagName('h2'); // You can change 'h2' to other headings if needed
foreach ($headingsElements as $heading) {
    $headings[] = $heading->textContent;
}

$abstractElements = $dom->getElementsByTagName('p'); // You can change 'p' to other elements containing abstracts
foreach ($abstractElements as $abstract) {
    $abstracts[] = $abstract->textContent;
}

$pictureElements = $dom->getElementsByTagName('img');
foreach ($pictureElements as $picture) {
    $pictures[] = $picture->getAttribute('src');
}

$linkElements = $dom->getElementsByTagName('a');
foreach ($linkElements as $link) {
    $links[] = $link->getAttribute('href');
}
if (count($headingsElements) >= count($abstractElements) 
&& count($headingsElements) >= count($pictureElements) 
&& count($headingsElements) >= count($linkElements)){
	$arrrayCount =  count($headingsElements);
}elseif(count($abstractElements) >= count($headingsElements) 
&& count($abstractElements) >= count($pictureElements) 
&& count($abstractElements) >= count($linkElements)){
	$arrrayCount =  count($abstractElements);
}elseif(count($pictureElements) >= count($headingsElements) 
&& count($pictureElements) >= count($abstractElements) 
&& count($pictureElements) >= count($linkElements)){
	$arrrayCount =  count($pictureElements);
}elseif(count($linkElements) >= count($headingsElements) 
&& count($linkElements) >= count($abstractElements) 
&& count($linkElements) >= count($pictureElements)){
	$arrrayCount =  count($linkElements);
}

for($i=0;$i<$arrrayCount;$i++){
    if(isset($headings[$i])){$heading = $headings[$i];}else{$heading = '';}
	if(isset($links[$i])){$link = $links[$i];}else{$link = '';}
	if(isset($pictures[$i])){$picture = $pictures[$i];}else{$picture = '';}
	if(isset($abstracts[$i])){$abstract = $abstracts[$i];}else{$abstract = '';}
	$output = $conn->insertWikiSections($heading,$link,$picture,$abstract,$arrrayCount);
}

echo $output;


?>