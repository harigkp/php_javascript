<?php
    class connection{
        
        function __construct(){
             require_once($_SERVER['DOCUMENT_ROOT'].dirname($_SERVER["PHP_SELF"]).'/conn.php');
			 $this->conn = mysqli_connect(DB_SERVER, DB_USER, DB_PASSWORD, DB_DATABASE);   
        }
        
        function insertWikiSections($title,$url,$picture,$abstract,$i){
			$title= mysqli_real_escape_string($this->conn, stripcslashes(SUBSTR($title, 0, 230)));
			$url= mysqli_real_escape_string($this->conn, stripcslashes(SUBSTR($url, 0, 240)));
			$picture= mysqli_real_escape_string($this->conn, stripcslashes(SUBSTR($picture, 0, 240)));
			$abstract= mysqli_real_escape_string($this->conn, stripcslashes(SUBSTR($abstract, 0, 256)));
			$sql= "INSERT INTO wiki_sections(title, url, picture, abstract)
			VALUES('$title', '$url', '$picture', '$abstract')"; 
			$stmt = mysqli_query($this->conn, $sql);
			
        }
		
        function getResults(){
          $sql= "SELECT * FROM `results` ORDER BY `results`.`id` ASC";
          return mysqli_query($this->conn, $sql);			
        }			
		
	}
	
	$conn = new connection;