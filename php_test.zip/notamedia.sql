-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Nov 06, 2023 at 08:23 PM
-- Server version: 10.4.28-MariaDB
-- PHP Version: 8.2.4

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `notamedia`
--

-- --------------------------------------------------------

--
-- Table structure for table `results`
--

CREATE TABLE `results` (
  `id` int(11) NOT NULL,
  `name` varchar(20) NOT NULL,
  `status` tinyint(4) DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `results`
--

INSERT INTO `results` (`id`, `name`, `status`, `created_at`) VALUES
(1, 'normal', 1, '2023-11-06 22:41:32'),
(2, 'illegal', 1, '2023-11-06 22:41:32'),
(3, 'failed', 1, '2023-11-06 22:41:57'),
(4, 'success', 1, '2023-11-06 22:41:57');

-- --------------------------------------------------------

--
-- Table structure for table `test`
--

CREATE TABLE `test` (
  `id` int(11) NOT NULL,
  `script_name` varchar(25) NOT NULL,
  `start_time` datetime NOT NULL DEFAULT current_timestamp(),
  `end_time` datetime NOT NULL DEFAULT current_timestamp(),
  `result` tinyint(4) NOT NULL COMMENT '1=>normal, 2=>illegal, 3=>failed, 4=>success'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `test`
--

INSERT INTO `test` (`id`, `script_name`, `start_time`, `end_time`, `result`) VALUES
(1, 'fsfsf', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1),
(2, 'fsfsf', '2023-11-06 00:00:00', '2023-11-06 00:00:00', 1),
(3, 'fsfsf', '2023-11-06 12:00:00', '2023-11-06 12:00:00', 1),
(4, 'fsfsf', '2023-10-29 12:00:00', '2023-11-08 12:30:00', 1),
(5, 'fsfsf', '2023-10-29 12:00:00', '2023-11-09 01:30:00', 1),
(6, 'fsfsf', '2023-10-29 12:00:00', '2023-11-09 01:30:00', 1);

-- --------------------------------------------------------

--
-- Table structure for table `wiki_sections`
--

CREATE TABLE `wiki_sections` (
  `id` int(11) NOT NULL,
  `date_created` datetime NOT NULL DEFAULT current_timestamp(),
  `title` varchar(230) DEFAULT NULL,
  `url` varchar(240) DEFAULT NULL,
  `picture` varchar(240) DEFAULT NULL,
  `abstract` varchar(256) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `wiki_sections`
--

INSERT INTO `wiki_sections` (`id`, `date_created`, `title`, `url`, `picture`, `abstract`) VALUES
(5, '2023-11-06 12:20:02', 'Contents', '#bodyContent', '/static/images/icons/wikipedia.png', '\n'),
(6, '2023-11-06 12:20:02', 'Background[edit]', '/wiki/Main_Page', '/static/images/mobile/copyright/wikipedia-wordmark-en.svg', 'Dark Archives: A Librarian\'s Investigation into the Science and History of Books Bound in Human Skin is a 2020 non-fiction book by the medical librarian and death-positive advocate Megan Rosenbloom. Dealing with anthropodermic bibliopegy, the binding of bo'),
(7, '2023-11-06 12:20:02', 'Synopsis[edit]', '/wiki/Wikipedia:Contents', '/static/images/mobile/copyright/wikipedia-tagline-en.svg', 'The book focuses on the relationship between anthropodermic bibliopegy and the history of medicine; most confirmed cases of such books were created or owned by medical professionals, in contrast to common stereotypes that they were associated with Nazi Ger'),
(8, '2023-11-06 12:20:02', 'Research and publication[edit]', '/wiki/Portal:Current_events', '//upload.wikimedia.org/wikipedia/en/thumb/e/e7/Cscr-featured.svg/20px-Cscr-featured.svg.png', 'Dark Archives was published by Farrar, Straus and Giroux in October 2020. Critics praised the book for its thorough research, clear writing, and enthusiasm for rare books and their history. The perspective and history through which Rosenbloom approached th'),
(9, '2023-11-06 12:20:02', 'Reception[edit]', '/wiki/Special:Random', '//upload.wikimedia.org/wikipedia/en/thumb/2/21/Dark_Archives_cover.png/220px-Dark_Archives_cover.png', 'A book on the human soul merits that it be given human clothing.'),
(10, '2023-11-06 12:20:03', 'See also[edit]', '/wiki/Wikipedia:About', '//upload.wikimedia.org/wikipedia/commons/thumb/a/a6/S._Pinaeus%2C_De_integritatis_et_corruptionis_virginum..._Wellcome_L0030772.jpg/220px-S._Pinaeus%2C_De_integritatis_et_corruptionis_virginum..._Wellcome_L0030772.jpg', 'Anthropodermic bibliopegy—the binding of books in human skin—peaked in the 19th century. The practice was most popular among doctors, who had access to cadavers in their profession. It was nonetheless a rare phenomenon even at the peak of its popularit'),
(11, '2023-11-06 12:20:03', 'Notes[edit]', '//en.wikipedia.org/wiki/Wikipedia:Contact_us', '//upload.wikimedia.org/wikipedia/commons/thumb/4/4c/Cruelty4.JPG/290px-Cruelty4.JPG', 'The ability to unequivocally identify book bindings as being of human skin dates only to the mid-2010s. For many years, identification tended to be visual, based predominantly on the structure of pores such as hair follicles in the skin. This could be comb'),
(12, '2023-11-06 12:20:03', 'References[edit]', 'https://donate.wikimedia.org/wiki/Special:FundraiserRedirector?utm_source=donate&utm_medium=sidebar&utm_campaign=C13_en.wikipedia.org&uselang=en', '//upload.wikimedia.org/wikipedia/commons/thumb/b/b0/Megan_Rosenbloom_%28cropped%29.jpg/220px-Megan_Rosenbloom_%28cropped%29.jpg', 'Megan Rosenbloom is a collection strategies librarian at the University of California, Los Angeles, and formerly a medical librarian at the University of Southern California.[9][10] Rosenbloom is a high-profile member of the death-positive movement, an ide'),
(13, '2023-11-06 12:20:03', '', '/wiki/Help:Contents', 'https://login.wikimedia.org/wiki/Special:CentralAutoLogin/start?type=1x1', 'Dark Archives revolves around the history, provenance, and myths of anthropodermic books. It focuses particularly on the relationship of anthropodermic bibliopegy with the history of medicine and medical ethics; most books confirmed to be bound in human sk'),
(14, '2023-11-06 12:20:03', '', '/wiki/Help:Introduction', '/static/images/footer/wikimedia-button.png', 'The book\'s preface and first chapter describe Rosenbloom\'s experiences at Mütter that led her to research books bound in human skin. They discuss the history of confirming the provenance of such books, including visual examination, DNA testing, and peptid'),
(15, '2023-11-06 12:20:03', '', '/wiki/Wikipedia:Community_portal', '/static/images/footer/poweredby_mediawiki_88x31.png', 'Rosenbloom covers the variance in opinions about anthropodermic books amongst librarians and archivists. She recounts an interview with Paul Needham, a librarian at Princeton University Library, who is vocally opposed to the preservation of such bindings. '),
(16, '2023-11-06 12:20:03', '', '/wiki/Special:RecentChanges', '', 'Notable examples of books bound in human skin are described, as well as significant people involved, both doctors associated with the practice and the people whose skin was used to bind such books. Rosenbloom associates anthropodermic bibliopegy with succe'),
(17, '2023-11-06 12:20:03', '', '/wiki/Wikipedia:File_upload_wizard', '', 'The skin of many kinds of people was used in the process of bookbinding, and the methods through which they came to medical awareness varied. Some such people died indigent in hospitals, where the doctors of the day considered their remains too valuable fo'),
(18, '2023-11-06 12:20:03', '', '/wiki/Main_Page', '', 'The emergence and evolution of medical ethics is a focus of Dark Archives. Rosenbloom notes that people\'s consent to the use of their body after death is a relatively recent concern in medicine; she quotes a statistic that it was not until the 1960s that \"'),
(19, '2023-11-06 12:20:03', '', '/wiki/Special:Search', '', 'In the book\'s final chapter, Rosenbloom discusses anthropodermic books that are kept in private collections, rather than museums as in most confirmed cases. PMF testing of privately held books has generally discovered them to be fakes, but Rosenbloom and h'),
(20, '2023-11-06 12:20:03', '', '/w/index.php?title=Special:CreateAccount&returnto=Dark+Archives', '', 'Rosenbloom spent six years researching Dark Archives, during which time she visited literary archives and private collectors across Europe and America.[1][5][17] Her research was not only oriented around the books themselves, but also the process and logis'),
(21, '2023-11-06 12:20:03', '', '/w/index.php?title=Special:UserLogin&returnto=Dark+Archives', '', 'Librarians, archivists, and other researchers were interviewed for Dark Archives. Some of these figures disagreed with Rosenbloom\'s attitude towards books bound in human skin, including Paul Needham, then the head librarian of the Scheide Library at Prince'),
(22, '2023-11-06 12:20:03', '', '/w/index.php?title=Special:CreateAccount&returnto=Dark+Archives', '', 'The book presents biographies of several figures discussed in it, such as John Stockton Hough, the physician who bound the three anthropodermic books at the Mütter Museum. Hough was a 19th-century gynecologist considered pre-eminent in his field, noted fo'),
(23, '2023-11-06 12:20:03', '', '/w/index.php?title=Special:UserLogin&returnto=Dark+Archives', '', 'Dark Archives was agented by Anna Sproul-Latimer at Neon Literary and published through Farrar, Straus and Giroux, an imprint of Macmillan Publishers, in October 2020. It is 288 pages long.[20]\n'),
(24, '2023-11-06 12:20:03', '', '/wiki/Help:Introduction', '', 'Dark Archives received generally positive reviews.[21] Its reception discussed the depth of Rosenbloom\'s research,[1][5][22] the accessible writing style,[13][23][24] and the passion she demonstrated for the history and preservation of rare books. Her inte'),
(25, '2023-11-06 12:20:03', '', '/wiki/Special:MyContributions', '', 'The book was praised by reviewers for its depth of scholarship and its reckoning with ethical issues.[1][5][22] Christine Jacobson, a curator at the Houghton Library, reviewed Dark Archives for the Los Angeles Review of Books. Working from her own experien'),
(26, '2023-11-06 12:20:03', '', '/wiki/Special:MyTalk', '', 'Megan Nance, medical librarian at the Harvey Cushing/John Hay Whitney Medical Library at Yale University, reviewed the book positively in the Journal of the Medical Library Association. She commented on Rosenbloom\'s efforts to identify the people whose ski'),
(27, '2023-11-06 12:20:03', '', '#', '', 'The writing style, aesthetic sensibility, and philosophical leans of Dark Archives attracted attention from reviewers.[13][23][24] NPR deemed the book a \"titillating Halloween read\" that combined \"bloody thrills with historical fact and ethical nuance\", bu'),
(28, '2023-11-06 12:20:03', '', '#Background', '', 'Sheilah Ayers at the University of Lethbridge wrote in the Canadian Journal of Academic Librarianship that Dark Archives was \"accessible, engaging, and incredibly intriguing\", but highlighted how Rosenbloom\'s death-positive stance reached the point of bein'),
(29, '2023-11-06 12:20:03', '', '#Synopsis', '', 'Carolyn Sullivan at Emerging Library & Information Perspectives wrote a generally positive review, particularly taking note of the book\'s substantial bibliography and diversity of research sources, but warned that readers may be \"divided\" on the appropriat'),
(30, '2023-11-06 12:20:03', '', '#Research_and_publication', '', 'Several outlets included Dark Archives in their seasonal or annual book recommendations. Shortly after the book\'s release, The Week recommended it for fans of true crime,[27] and Wired described it as an unexpected \"delight\" that \"manages to be life-affirm'),
(31, '2023-11-06 12:20:03', '', '#Reception', '', ''),
(32, '2023-11-06 12:20:03', '', '#Scholarship', '', ''),
(33, '2023-11-06 12:20:03', '', '#Aesthetic_and_philosophy', '', ''),
(34, '2023-11-06 12:20:03', '', '#Recommendations', '', ''),
(35, '2023-11-06 12:20:03', '', '#See_also', '', ''),
(36, '2023-11-06 12:20:03', '', '#Notes', '', ''),
(37, '2023-11-06 12:20:03', '', '#References', '', ''),
(38, '2023-11-06 12:20:03', '', 'https://www.wikidata.org/wiki/Special:EntityPage/Q101093537#sitelinks-wikipedia', '', ''),
(39, '2023-11-06 12:20:03', '', '/wiki/Dark_Archives', '', ''),
(40, '2023-11-06 12:20:03', '', '/wiki/Talk:Dark_Archives', '', ''),
(41, '2023-11-06 12:20:03', '', '/wiki/Dark_Archives', '', ''),
(42, '2023-11-06 12:20:03', '', '/w/index.php?title=Dark_Archives&action=edit', '', ''),
(43, '2023-11-06 12:20:03', '', '/w/index.php?title=Dark_Archives&action=history', '', ''),
(44, '2023-11-06 12:20:03', '', '/wiki/Dark_Archives', '', ''),
(45, '2023-11-06 12:20:03', '', '/w/index.php?title=Dark_Archives&action=edit', '', ''),
(46, '2023-11-06 12:20:03', '', '/w/index.php?title=Dark_Archives&action=history', '', ''),
(47, '2023-11-06 12:20:03', '', '/wiki/Special:WhatLinksHere/Dark_Archives', '', ''),
(48, '2023-11-06 12:20:03', '', '/wiki/Special:RecentChangesLinked/Dark_Archives', '', ''),
(49, '2023-11-06 12:20:03', '', '/wiki/Wikipedia:File_Upload_Wizard', '', ''),
(50, '2023-11-06 12:20:03', '', '/wiki/Special:SpecialPages', '', ''),
(51, '2023-11-06 12:20:03', '', '/w/index.php?title=Dark_Archives&oldid=1183656472', '', ''),
(52, '2023-11-06 12:20:03', '', '/w/index.php?title=Dark_Archives&action=info', '', ''),
(53, '2023-11-06 12:20:03', '', '/w/index.php?title=Special:CiteThisPage&page=Dark_Archives&id=1183656472&wpFormIdentifier=titleform', '', ''),
(54, '2023-11-06 12:20:03', '', '/w/index.php?title=Special:UrlShortener&url=https%3A%2F%2Fen.wikipedia.org%2Fwiki%2FDark_Archives', '', ''),
(55, '2023-11-06 12:20:03', '', 'https://www.wikidata.org/wiki/Special:EntityPage/Q101093537', '', ''),
(56, '2023-11-06 12:20:03', '', '/w/index.php?title=Special:DownloadAsPdf&page=Dark_Archives&action=show-download-screen', '', ''),
(57, '2023-11-06 12:20:03', '', '/w/index.php?title=Dark_Archives&printable=yes', '', ''),
(58, '2023-11-06 12:20:03', '', '/wiki/Wikipedia:Featured_articles', '', ''),
(59, '2023-11-06 12:20:03', '', '/wiki/File:Dark_Archives_cover.png', '', ''),
(60, '2023-11-06 12:20:03', '', '/wiki/Megan_Rosenbloom', '', ''),
(61, '2023-11-06 12:20:03', '', '/wiki/Farrar,_Straus_and_Giroux', '', ''),
(62, '2023-11-06 12:20:03', '', '/wiki/ISBN_(identifier)', '', ''),
(63, '2023-11-06 12:20:03', '', '/wiki/Special:BookSources/978-0-374-13470-9', '', ''),
(64, '2023-11-06 12:20:03', '', '/wiki/Dewey_Decimal_Classification', '', ''),
(65, '2023-11-06 12:20:03', '', '/wiki/Medical_library', '', ''),
(66, '2023-11-06 12:20:03', '', '/wiki/Death-positive', '', ''),
(67, '2023-11-06 12:20:03', '', '/wiki/Megan_Rosenbloom', '', ''),
(68, '2023-11-06 12:20:03', '', '/wiki/Anthropodermic_bibliopegy', '', ''),
(69, '2023-11-06 12:20:03', '', '/wiki/List_of_common_misconceptions', '', ''),
(70, '2023-11-06 12:20:03', '', '/wiki/Nazi_Germany', '', ''),
(71, '2023-11-06 12:20:03', '', '/wiki/Serial_killer', '', ''),
(72, '2023-11-06 12:20:03', '', '/wiki/French_Revolution', '', ''),
(73, '2023-11-06 12:20:03', '', '/wiki/Medical_ethics', '', ''),
(74, '2023-11-06 12:20:03', '', '/wiki/Princeton_University_Library', '', ''),
(75, '2023-11-06 12:20:03', '', '/wiki/Paul_Needham_(librarian)', '', ''),
(76, '2023-11-06 12:20:03', '', '/wiki/Farrar,_Straus_and_Giroux', '', ''),
(77, '2023-11-06 12:20:03', '', '/w/index.php?title=Dark_Archives&action=edit&section=1', '', ''),
(78, '2023-11-06 12:20:03', '', '/wiki/Houghton_Library', '', ''),
(79, '2023-11-06 12:20:03', '', '/w/index.php?title=Des_destin%C3%A9es_de_l%27ame&action=edit&redlink=1', '', ''),
(80, '2023-11-06 12:20:03', '', '/wiki/Ars%C3%A8ne_Houssaye', '', ''),
(81, '2023-11-06 12:20:03', '', '#cite_note-lareview-1', '', ''),
(82, '2023-11-06 12:20:03', '', '/wiki/File:S._Pinaeus,_De_integritatis_et_corruptionis_virginum..._Wellcome_L0030772.jpg', '', ''),
(83, '2023-11-06 12:20:03', '', '/wiki/Wellcome_Library', '', ''),
(84, '2023-11-06 12:20:03', '', '#cite_note-da0-2', '', ''),
(85, '2023-11-06 12:20:03', '', '#cite_note-3', '', ''),
(86, '2023-11-06 12:20:03', '', '/wiki/Anthropodermic_bibliopegy', '', ''),
(87, '2023-11-06 12:20:03', '', '/w/index.php?title=Anthropodermic_Book_Project&action=edit&redlink=1', '', ''),
(88, '2023-11-06 12:20:03', '', '#cite_note-bbc-4', '', ''),
(89, '2023-11-06 12:20:03', '', '#cite_note-undark-5', '', ''),
(90, '2023-11-06 12:20:03', '', '/wiki/List_of_common_misconceptions', '', ''),
(91, '2023-11-06 12:20:03', '', '/wiki/Nazi_Germany', '', ''),
(92, '2023-11-06 12:20:03', '', '/wiki/The_Holocaust', '', ''),
(93, '2023-11-06 12:20:03', '', '/wiki/Lampshades_made_from_human_skin', '', ''),
(94, '2023-11-06 12:20:03', '', '#cite_note-nyt-6', '', ''),
(95, '2023-11-06 12:20:03', '', '#cite_note-crl-7', '', ''),
(96, '2023-11-06 12:20:03', '', '#cite_note-rbm-8', '', ''),
(97, '2023-11-06 12:20:03', '', '/wiki/Hair_follicle', '', ''),
(98, '2023-11-06 12:20:03', '', '/wiki/DNA_testing', '', ''),
(99, '2023-11-06 12:20:03', '', '#cite_note-rbm-8', '', ''),
(100, '2023-11-06 12:20:03', '', '/wiki/Tanning_(leather)', '', ''),
(101, '2023-11-06 12:20:03', '', '#cite_note-watermark-9', '', ''),
(102, '2023-11-06 12:20:03', '', '/wiki/Peptide_mass_fingerprinting', '', ''),
(103, '2023-11-06 12:20:03', '', '/wiki/Gold_standard_(test)', '', ''),
(104, '2023-11-06 12:20:03', '', '/wiki/Harvard_University', '', ''),
(105, '2023-11-06 12:20:03', '', '#cite_note-lareview-1', '', ''),
(106, '2023-11-06 12:20:03', '', '#cite_note-rbm-8', '', ''),
(107, '2023-11-06 12:20:03', '', '#cite_note-watermark-9', '', ''),
(108, '2023-11-06 12:20:03', '', '/wiki/Megan_Rosenbloom', '', ''),
(109, '2023-11-06 12:20:03', '', '/wiki/Collections_management', '', ''),
(110, '2023-11-06 12:20:03', '', '/wiki/University_of_California,_Los_Angeles', '', ''),
(111, '2023-11-06 12:20:03', '', '/wiki/University_of_Southern_California', '', ''),
(112, '2023-11-06 12:20:03', '', '#cite_note-alm-10', '', ''),
(113, '2023-11-06 12:20:03', '', '#cite_note-da1-11', '', ''),
(114, '2023-11-06 12:20:03', '', '/wiki/Taboo_on_the_dead', '', ''),
(115, '2023-11-06 12:20:03', '', '/wiki/Caitlin_Doughty', '', ''),
(116, '2023-11-06 12:20:03', '', '/wiki/The_Order_of_the_Good_Death', '', ''),
(117, '2023-11-06 12:20:03', '', '#cite_note-newsroom-12', '', ''),
(118, '2023-11-06 12:20:03', '', '#cite_note-pacc-13', '', ''),
(119, '2023-11-06 12:20:03', '', '#cite_note-lareview-1', '', ''),
(120, '2023-11-06 12:20:03', '', '#cite_note-undark-5', '', ''),
(121, '2023-11-06 12:20:03', '', '#cite_note-elip-14', '', ''),
(122, '2023-11-06 12:20:03', '', '/wiki/M%C3%BCtter_Museum', '', ''),
(123, '2023-11-06 12:20:03', '', '#cite_note-da2-15', '', ''),
(124, '2023-11-06 12:20:03', '', '/w/index.php?title=Dark_Archives&action=edit&section=2', '', ''),
(125, '2023-11-06 12:20:03', '', '/wiki/File:Cruelty4.JPG', '', ''),
(126, '2023-11-06 12:20:03', '', '/wiki/The_Four_Stages_of_Cruelty', '', ''),
(127, '2023-11-06 12:20:03', '', '/wiki/William_Hogarth', '', ''),
(128, '2023-11-06 12:20:03', '', '/wiki/Medical_ethics', '', ''),
(129, '2023-11-06 12:20:03', '', '/wiki/Peptide_mass_fingerprinting', '', ''),
(130, '2023-11-06 12:20:03', '', '/wiki/French_Revolution', '', ''),
(131, '2023-11-06 12:20:03', '', '/wiki/Meudon', '', ''),
(132, '2023-11-06 12:20:03', '', '/wiki/Paul_Needham_(librarian)', '', ''),
(133, '2023-11-06 12:20:03', '', '/wiki/Princeton_University_Library', '', ''),
(134, '2023-11-06 12:20:03', '', 'https://en.wiktionary.org/wiki/triage', '', ''),
(135, '2023-11-06 12:20:03', '', '/wiki/Bibliophiles', '', ''),
(136, '2023-11-06 12:20:03', '', '/wiki/Erotica', '', ''),
(137, '2023-11-06 12:20:03', '', '#cite_note-da3-16', '', ''),
(138, '2023-11-06 12:20:03', '', '/wiki/Red_Barn_Murder', '', ''),
(139, '2023-11-06 12:20:03', '', '/wiki/Resurrectionists_in_the_United_Kingdom#Dissection_and_anatomy', '', ''),
(140, '2023-11-06 12:20:03', '', '/wiki/James_Allen_(highwayman)', '', ''),
(141, '2023-11-06 12:20:03', '', '/wiki/Narrative_of_the_Life_of_James_Allen', '', ''),
(142, '2023-11-06 12:20:03', '', '#cite_note-da4-17', '', ''),
(143, '2023-11-06 12:20:03', '', '/w/index.php?title=Postmortem_tattoo_preservation&action=edit&redlink=1', '', ''),
(144, '2023-11-06 12:20:03', '', '/w/index.php?title=Save_My_Ink_Forever&action=edit&redlink=1', '', ''),
(145, '2023-11-06 12:20:03', '', '/wiki/The_Gold-Bug', '', ''),
(146, '2023-11-06 12:20:03', '', '/wiki/Edgar_Allan_Poe', '', ''),
(147, '2023-11-06 12:20:03', '', '/wiki/Novelette_(literature)', '', ''),
(148, '2023-11-06 12:20:03', '', '/wiki/John_Steinbeck', '', ''),
(149, '2023-11-06 12:20:03', '', '/w/index.php?title=Dark_Archives&action=edit&section=3', '', ''),
(150, '2023-11-06 12:20:03', '', '/wiki/File:Megan_Rosenbloom_(cropped).jpg', '', ''),
(151, '2023-11-06 12:20:03', '', '/wiki/Megan_Rosenbloom', '', ''),
(152, '2023-11-06 12:20:03', '', '#cite_note-lareview-1', '', ''),
(153, '2023-11-06 12:20:03', '', '#cite_note-nyt-6', '', ''),
(154, '2023-11-06 12:20:03', '', '#cite_note-latimes-18', '', ''),
(155, '2023-11-06 12:20:03', '', '/wiki/Tannery', '', ''),
(156, '2023-11-06 12:20:03', '', '#cite_note-undark-5', '', ''),
(157, '2023-11-06 12:20:03', '', '/wiki/Paul_Needham_(librarian)', '', ''),
(158, '2023-11-06 12:20:03', '', '/wiki/Scheide_Library', '', ''),
(159, '2023-11-06 12:20:03', '', '/wiki/Princeton_University', '', ''),
(160, '2023-11-06 12:20:03', '', '#cite_note-elip-14', '', ''),
(161, '2023-11-06 12:20:03', '', '#cite_note-princeton-19', '', ''),
(162, '2023-11-06 12:20:03', '', '#cite_note-elip-14', '', ''),
(163, '2023-11-06 12:20:03', '', '/w/index.php?title=John_Stockton_Hough&action=edit&redlink=1', '', ''),
(164, '2023-11-06 12:20:03', '', '/wiki/M%C3%BCtter_Museum', '', ''),
(165, '2023-11-06 12:20:03', '', '/wiki/Gynecologist', '', ''),
(166, '2023-11-06 12:20:03', '', '/wiki/Speculum_(medical)', '', ''),
(167, '2023-11-06 12:20:03', '', '/wiki/Incunabula', '', ''),
(168, '2023-11-06 12:20:03', '', '#cite_note-lareview-1', '', ''),
(169, '2023-11-06 12:20:03', '', '#cite_note-qjs-20', '', ''),
(170, '2023-11-06 12:20:03', '', '/wiki/Los_Angeles_Review_of_Books', '', ''),
(171, '2023-11-06 12:20:03', '', '#cite_note-lareview-1', '', ''),
(172, '2023-11-06 12:20:03', '', '/wiki/Farrar,_Straus_and_Giroux', '', ''),
(173, '2023-11-06 12:20:03', '', '/wiki/Macmillan_Publishers', '', ''),
(174, '2023-11-06 12:20:03', '', '#cite_note-pw-21', '', ''),
(175, '2023-11-06 12:20:03', '', '/w/index.php?title=Dark_Archives&action=edit&section=4', '', ''),
(176, '2023-11-06 12:20:03', '', '#cite_note-bookmarks-22', '', ''),
(177, '2023-11-06 12:20:03', '', '#cite_note-lareview-1', '', ''),
(178, '2023-11-06 12:20:03', '', '#cite_note-nyt-6', '', ''),
(179, '2023-11-06 12:20:03', '', '#cite_note-jmla-23', '', ''),
(180, '2023-11-06 12:20:03', '', '#cite_note-elip-14', '', ''),
(181, '2023-11-06 12:20:03', '', '#cite_note-npr-24', '', ''),
(182, '2023-11-06 12:20:03', '', '#cite_note-cjal-25', '', ''),
(183, '2023-11-06 12:20:03', '', '#cite_note-lareview-1', '', ''),
(184, '2023-11-06 12:20:03', '', '#cite_note-elip-14', '', ''),
(185, '2023-11-06 12:20:03', '', '/w/index.php?title=Dark_Archives&action=edit&section=5', '', ''),
(186, '2023-11-06 12:20:03', '', '#cite_note-lareview-1', '', ''),
(187, '2023-11-06 12:20:03', '', '#cite_note-nyt-6', '', ''),
(188, '2023-11-06 12:20:03', '', '#cite_note-jmla-23', '', ''),
(189, '2023-11-06 12:20:03', '', '/wiki/Houghton_Library', '', ''),
(190, '2023-11-06 12:20:04', '', '/wiki/Los_Angeles_Review_of_Books', '', ''),
(191, '2023-11-06 12:20:04', '', '#cite_note-lareview-1', '', ''),
(192, '2023-11-06 12:20:04', '', '/wiki/James_Hamblin_(journalist)', '', ''),
(193, '2023-11-06 12:20:04', '', '/wiki/Anthropodermic_bibliopegy', '', ''),
(194, '2023-11-06 12:20:04', '', '/wiki/The_New_York_Times', '', ''),
(195, '2023-11-06 12:20:04', '', '#cite_note-nyt-6', '', ''),
(196, '2023-11-06 12:20:04', '', '/wiki/Harvey_Cushing/John_Hay_Whitney_Medical_Library', '', ''),
(197, '2023-11-06 12:20:04', '', '/wiki/Yale_University', '', ''),
(198, '2023-11-06 12:20:04', '', '/wiki/JMLA', '', ''),
(199, '2023-11-06 12:20:04', '', '#cite_note-jmla-23', '', ''),
(200, '2023-11-06 12:20:04', '', '/wiki/Cultural_Geographies', '', ''),
(201, '2023-11-06 12:20:04', '', '/wiki/Critical_theory', '', ''),
(202, '2023-11-06 12:20:04', '', '#cite_note-cg-26', '', ''),
(203, '2023-11-06 12:20:04', '', '#cite_note-editor-27', '', ''),
(204, '2023-11-06 12:20:04', '', '/wiki/Special_collections', '', ''),
(205, '2023-11-06 12:20:04', '', '#cite_note-crl-7', '', ''),
(206, '2023-11-06 12:20:04', '', '/w/index.php?title=Dark_Archives&action=edit&section=6', '', ''),
(207, '2023-11-06 12:20:04', '', '#cite_note-elip-14', '', ''),
(208, '2023-11-06 12:20:04', '', '#cite_note-npr-24', '', ''),
(209, '2023-11-06 12:20:04', '', '#cite_note-cjal-25', '', ''),
(210, '2023-11-06 12:20:04', '', '/wiki/NPR', '', ''),
(211, '2023-11-06 12:20:04', '', '#cite_note-npr-24', '', ''),
(212, '2023-11-06 12:20:04', '', '/wiki/Publishers_Weekly', '', ''),
(213, '2023-11-06 12:20:04', '', '#cite_note-pw-21', '', ''),
(214, '2023-11-06 12:20:04', '', '/wiki/University_of_Lethbridge', '', ''),
(215, '2023-11-06 12:20:04', '', '#cite_note-cjal-25', '', ''),
(216, '2023-11-06 12:20:04', '', '/wiki/Ologies_(podcast)', '', ''),
(217, '2023-11-06 12:20:04', '', '#cite_note-elip-14', '', ''),
(218, '2023-11-06 12:20:04', '', '/w/index.php?title=Dark_Archives&action=edit&section=7', '', ''),
(219, '2023-11-06 12:20:04', '', '/wiki/The_Week', '', ''),
(220, '2023-11-06 12:20:04', '', '/wiki/True_crime', '', ''),
(221, '2023-11-06 12:20:04', '', '#cite_note-theweek-28', '', ''),
(222, '2023-11-06 12:20:04', '', '/wiki/Wired_(magazine)', '', ''),
(223, '2023-11-06 12:20:04', '', '#cite_note-wired-29', '', ''),
(224, '2023-11-06 12:20:04', '', '/wiki/Barack_Obama', '', ''),
(225, '2023-11-06 12:20:04', '', '/wiki/A_Promised_Land', '', ''),
(226, '2023-11-06 12:20:04', '', '/wiki/Pamela_Sneed', '', ''),
(227, '2023-11-06 12:20:04', '', '/w/index.php?title=Funeral_Diva&action=edit&redlink=1', '', ''),
(228, '2023-11-06 12:20:04', '', '/wiki/National_Book_Award', '', ''),
(229, '2023-11-06 12:20:05', '', '/wiki/Blockchain_Chicken_Farm', '', ''),
(230, '2023-11-06 12:20:05', '', '#cite_note-nyt2-30', '', ''),
(231, '2023-11-06 12:20:05', '', '/wiki/Library_Journal', '', ''),
(232, '2023-11-06 12:20:05', '', '#cite_note-lj-31', '', ''),
(233, '2023-11-06 12:20:05', '', '/w/index.php?title=Dark_Archives&action=edit&section=8', '', ''),
(234, '2023-11-06 12:20:05', '', '/wiki/Dark_academia', '', ''),
(235, '2023-11-06 12:20:05', '', '/wiki/Danse_Macabre', '', ''),
(236, '2023-11-06 12:20:05', '', '/wiki/List_of_books_bound_in_human_skin', '', ''),
(237, '2023-11-06 12:20:05', '', '/w/index.php?title=Dark_Archives&action=edit&section=9', '', ''),
(238, '2023-11-06 12:20:05', '', '#cite_ref-3', '', ''),
(239, '2023-11-06 12:20:05', '', '#cite_note-da0-2', '', ''),
(240, '2023-11-06 12:20:05', '', '/w/index.php?title=Dark_Archives&action=edit&section=10', '', ''),
(241, '2023-11-06 12:20:05', '', '#cite_ref-lareview_1-0', '', ''),
(242, '2023-11-06 12:20:05', '', '#cite_ref-lareview_1-1', '', ''),
(243, '2023-11-06 12:20:05', '', '#cite_ref-lareview_1-2', '', ''),
(244, '2023-11-06 12:20:05', '', '#cite_ref-lareview_1-3', '', ''),
(245, '2023-11-06 12:20:05', '', '#cite_ref-lareview_1-4', '', ''),
(246, '2023-11-06 12:20:05', '', '#cite_ref-lareview_1-5', '', ''),
(247, '2023-11-06 12:20:05', '', '#cite_ref-lareview_1-6', '', ''),
(248, '2023-11-06 12:20:05', '', '#cite_ref-lareview_1-7', '', ''),
(249, '2023-11-06 12:20:05', '', '#cite_ref-lareview_1-8', '', ''),
(250, '2023-11-06 12:20:05', '', '#cite_ref-lareview_1-9', '', ''),
(251, '2023-11-06 12:20:05', '', 'https://web.archive.org/web/20230709135427/https://lareviewofbooks.org/article/a-look-at-anthropodermic-bibliopegy-on-megan-rosenblooms-dark-archives/', '', ''),
(252, '2023-11-06 12:20:05', '', 'https://lareviewofbooks.org/article/a-look-at-anthropodermic-bibliopegy-on-megan-rosenblooms-dark-archives/', '', ''),
(253, '2023-11-06 12:20:05', '', '#cite_ref-da0_2-0', '', ''),
(254, '2023-11-06 12:20:05', '', '#cite_ref-da0_2-1', '', ''),
(255, '2023-11-06 12:20:05', '', '/wiki/ISBN_(identifier)', '', ''),
(256, '2023-11-06 12:20:05', '', '/wiki/Special:BookSources/978-0-374-13470-9', '', ''),
(257, '2023-11-06 12:20:05', '', '#cite_ref-bbc_4-0', '', ''),
(258, '2023-11-06 12:20:05', '', 'https://web.archive.org/web/20230709135811/https://www.bbc.com/news/magazine-27903742', '', ''),
(259, '2023-11-06 12:20:05', '', '/wiki/BBC_News', '', ''),
(260, '2023-11-06 12:20:05', '', 'https://www.bbc.com/news/magazine-27903742', '', ''),
(261, '2023-11-06 12:20:05', '', '#cite_ref-undark_5-0', '', ''),
(262, '2023-11-06 12:20:05', '', '#cite_ref-undark_5-1', '', ''),
(263, '2023-11-06 12:20:05', '', '#cite_ref-undark_5-2', '', ''),
(264, '2023-11-06 12:20:05', '', 'https://web.archive.org/web/20230709140137/https://undark.org/2020/11/20/book-review-dark-archives/', '', ''),
(265, '2023-11-06 12:20:05', '', 'https://undark.org/2020/11/20/book-review-dark-archives/', '', ''),
(266, '2023-11-06 12:20:05', '', '#cite_ref-nyt_6-0', '', ''),
(267, '2023-11-06 12:20:05', '', '#cite_ref-nyt_6-1', '', ''),
(268, '2023-11-06 12:20:05', '', '#cite_ref-nyt_6-2', '', ''),
(269, '2023-11-06 12:20:05', '', '#cite_ref-nyt_6-3', '', ''),
(270, '2023-11-06 12:20:05', '', '#cite_ref-nyt_6-4', '', ''),
(271, '2023-11-06 12:20:05', '', 'https://web.archive.org/web/20230709140516/https://www.nytimes.com/2020/10/20/books/review/dark-archives-megan-rosenbloom.html', '', ''),
(272, '2023-11-06 12:20:05', '', 'https://www.nytimes.com/2020/10/20/books/review/dark-archives-megan-rosenbloom.html', '', ''),
(273, '2023-11-06 12:20:05', '', '#cite_ref-crl_7-0', '', ''),
(274, '2023-11-06 12:20:05', '', '#cite_ref-crl_7-1', '', ''),
(275, '2023-11-06 12:20:05', '', 'https://crl.acrl.org/index.php/crl/article/view/24990', '', ''),
(276, '2023-11-06 12:20:05', '', '/wiki/Doi_(identifier)', '', ''),
(277, '2023-11-06 12:20:05', '', 'https://doi.org/10.5860%2Fcrl.82.4.609', '', ''),
(278, '2023-11-06 12:20:05', '', '/wiki/S2CID_(identifier)', '', ''),
(279, '2023-11-06 12:20:05', '', 'https://api.semanticscholar.org/CorpusID:236225262', '', ''),
(280, '2023-11-06 12:20:05', '', 'https://web.archive.org/web/20220118182852/https://crl.acrl.org/index.php/crl/article/view/24990', '', ''),
(281, '2023-11-06 12:20:05', '', '#cite_ref-rbm_8-0', '', ''),
(282, '2023-11-06 12:20:05', '', '#cite_ref-rbm_8-1', '', ''),
(283, '2023-11-06 12:20:05', '', '#cite_ref-rbm_8-2', '', ''),
(284, '2023-11-06 12:20:05', '', 'https://rbm.acrl.org/index.php/rbm/article/view/9664', '', ''),
(285, '2023-11-06 12:20:05', '', 'https://web.archive.org/web/20220120055031/https://rbm.acrl.org/index.php/rbm/article/view/9664', '', ''),
(286, '2023-11-06 12:20:05', '', '#cite_ref-watermark_9-0', '', ''),
(287, '2023-11-06 12:20:05', '', '#cite_ref-watermark_9-1', '', ''),
(288, '2023-11-06 12:20:05', '', 'http://iis-exhibits.library.ucla.edu/alhhs/Watermark_Vol_39_No_3_Summer_2016.pdf', '', ''),
(289, '2023-11-06 12:20:05', '', 'https://web.archive.org/web/20190507100802/http://iis-exhibits.library.ucla.edu/alhhs/Watermark_Vol_39_No_3_Summer_2016.pdf', '', ''),
(290, '2023-11-06 12:20:05', '', '#cite_ref-alm_10-0', '', ''),
(291, '2023-11-06 12:20:05', '', 'https://americanlibrariesmagazine.org/2019/10/22/newsmaker-megan-rosenbloom/', '', ''),
(292, '2023-11-06 12:20:05', '', 'https://web.archive.org/web/20210528004933/https://americanlibrariesmagazine.org/2019/10/22/newsmaker-megan-rosenbloom/', '', ''),
(293, '2023-11-06 12:20:05', '', '#cite_ref-da1_11-0', '', ''),
(294, '2023-11-06 12:20:05', '', '/wiki/ISBN_(identifier)', '', ''),
(295, '2023-11-06 12:20:05', '', '/wiki/Special:BookSources/978-0-374-13470-9', '', ''),
(296, '2023-11-06 12:20:05', '', '#cite_ref-newsroom_12-0', '', ''),
(297, '2023-11-06 12:20:05', '', 'https://newsroom.ucla.edu/stories/megan-rosenbloom-dark-archives', '', ''),
(298, '2023-11-06 12:20:06', '', 'https://web.archive.org/web/20230820051546/https://newsroom.ucla.edu/stories/megan-rosenbloom-dark-archives', '', ''),
(299, '2023-11-06 12:20:06', '', '#cite_ref-pacc_13-0', '', ''),
(300, '2023-11-06 12:20:06', '', 'https://journals.library.ualberta.ca/ojs.cais-acsi.ca/index.php/cais-asci/article/view/1112', '', ''),
(301, '2023-11-06 12:20:06', '', '/wiki/Doi_(identifier)', '', ''),
(302, '2023-11-06 12:20:06', '', 'https://doi.org/10.29173%2Fcais1112', '', ''),
(303, '2023-11-06 12:20:06', '', 'https://web.archive.org/web/20230820051539/https://journals.library.ualberta.ca/ojs.cais-acsi.ca/index.php/cais-asci/article/view/1112', '', ''),
(304, '2023-11-06 12:20:06', '', '#cite_ref-elip_14-0', '', ''),
(305, '2023-11-06 12:20:06', '', '#cite_ref-elip_14-1', '', ''),
(306, '2023-11-06 12:20:06', '', '#cite_ref-elip_14-2', '', ''),
(307, '2023-11-06 12:20:06', '', '#cite_ref-elip_14-3', '', ''),
(308, '2023-11-06 12:20:06', '', '#cite_ref-elip_14-4', '', ''),
(309, '2023-11-06 12:20:06', '', '#cite_ref-elip_14-5', '', ''),
(310, '2023-11-06 12:20:06', '', '#cite_ref-elip_14-6', '', ''),
(311, '2023-11-06 12:20:06', '', 'https://web.archive.org/web/20230709142535/https://ojs.lib.uwo.ca/index.php/elip/article/view/13477/11326', '', ''),
(312, '2023-11-06 12:20:06', '', '/wiki/Doi_(identifier)', '', ''),
(313, '2023-11-06 12:20:06', '', 'https://doi.org/10.5206%2Felip.v4i1.13477', '', ''),
(314, '2023-11-06 12:20:06', '', '/wiki/S2CID_(identifier)', '', ''),
(315, '2023-11-06 12:20:06', '', 'https://api.semanticscholar.org/CorpusID:243612093', '', ''),
(316, '2023-11-06 12:20:06', '', 'https://ojs.lib.uwo.ca/index.php/elip/article/view/13477/11326', '', ''),
(317, '2023-11-06 12:20:06', '', '#cite_ref-da2_15-0', '', ''),
(318, '2023-11-06 12:20:06', '', '/wiki/ISBN_(identifier)', '', ''),
(319, '2023-11-06 12:20:06', '', '/wiki/Special:BookSources/978-0-374-13470-9', '', ''),
(320, '2023-11-06 12:20:06', '', '#cite_ref-da3_16-0', '', ''),
(321, '2023-11-06 12:20:06', '', '/wiki/ISBN_(identifier)', '', ''),
(322, '2023-11-06 12:20:06', '', '/wiki/Special:BookSources/978-0-374-13470-9', '', ''),
(323, '2023-11-06 12:20:06', '', '#cite_ref-da4_17-0', '', ''),
(324, '2023-11-06 12:20:06', '', '/wiki/ISBN_(identifier)', '', ''),
(325, '2023-11-06 12:20:06', '', '/wiki/Special:BookSources/978-0-374-13470-9', '', ''),
(326, '2023-11-06 12:20:06', '', '#cite_ref-latimes_18-0', '', ''),
(327, '2023-11-06 12:20:06', '', 'https://www.latimes.com/entertainment-arts/books/story/2020-10-27/megan-rosenbloom-profile-for-dark-archives', '', ''),
(328, '2023-11-06 12:20:06', '', 'https://web.archive.org/web/20210515225840/https://www.latimes.com/entertainment-arts/books/story/2020-10-27/megan-rosenbloom-profile-for-dark-archives', '', ''),
(329, '2023-11-06 12:20:06', '', '#cite_ref-princeton_19-0', '', ''),
(330, '2023-11-06 12:20:06', '', 'https://library.princeton.edu/news/general/2020-04-10/paul-needham-scheide-librarian-will-retire-after-22-years-service-princeton', '', ''),
(331, '2023-11-06 12:20:06', '', 'https://web.archive.org/web/20230703121359/https://library.princeton.edu/news/general/2020-04-10/paul-needham-scheide-librarian-will-retire-after-22-years-service-princeton', '', ''),
(332, '2023-11-06 12:20:07', '', '#cite_ref-qjs_20-0', '', ''),
(333, '2023-11-06 12:20:07', '', 'https://repository.upenn.edu/cgi/viewcontent.cgi?article=1651&context=asc_papers', '', ''),
(334, '2023-11-06 12:20:07', '', '/wiki/Doi_(identifier)', '', ''),
(335, '2023-11-06 12:20:07', '', 'https://doi.org/10.1080%2F00335639409384064', '', ''),
(336, '2023-11-06 12:20:07', '', 'https://web.archive.org/web/20230327062502/https://repository.upenn.edu/cgi/viewcontent.cgi?article=1651&context=asc_papers', '', ''),
(337, '2023-11-06 12:20:07', '', '#cite_ref-pw_21-0', '', ''),
(338, '2023-11-06 12:20:07', '', '#cite_ref-pw_21-1', '', ''),
(339, '2023-11-06 12:20:07', '', 'https://www.publishersweekly.com/978-0-374-13470-9', '', ''),
(340, '2023-11-06 12:20:07', '', 'https://web.archive.org/web/20230708143050/https://www.publishersweekly.com/978-0-374-13470-9', '', ''),
(341, '2023-11-06 12:20:07', '', '#cite_ref-bookmarks_22-0', '', ''),
(342, '2023-11-06 12:20:07', '', 'https://bookmarks.reviews/reviews/dark-archives-a-librarians-investigation-into-the-science-and-history-of-books-bound-in-human-skin/', '', ''),
(343, '2023-11-06 12:20:07', '', 'https://web.archive.org/web/20221007061510/https://bookmarks.reviews/reviews/dark-archives-a-librarians-investigation-into-the-science-and-history-of-books-bound-in-human-skin/', '', ''),
(344, '2023-11-06 12:20:07', '', '#cite_ref-jmla_23-0', '', ''),
(345, '2023-11-06 12:20:07', '', '#cite_ref-jmla_23-1', '', ''),
(346, '2023-11-06 12:20:07', '', '#cite_ref-jmla_23-2', '', ''),
(347, '2023-11-06 12:20:07', '', 'https://www.ncbi.nlm.nih.gov/pmc/articles/PMC9782372', '', ''),
(348, '2023-11-06 12:20:07', '', '/wiki/Doi_(identifier)', '', ''),
(349, '2023-11-06 12:20:07', '', 'https://doi.org/10.5195%2Fjmla.2022.1563', '', ''),
(350, '2023-11-06 12:20:07', '', '/wiki/PMC_(identifier)', '', ''),
(351, '2023-11-06 12:20:07', '', 'https://www.ncbi.nlm.nih.gov/pmc/articles/PMC9782372', '', ''),
(352, '2023-11-06 12:20:07', '', '#cite_ref-npr_24-0', '', ''),
(353, '2023-11-06 12:20:07', '', '#cite_ref-npr_24-1', '', ''),
(354, '2023-11-06 12:20:07', '', '#cite_ref-npr_24-2', '', ''),
(355, '2023-11-06 12:20:07', '', 'https://www.npr.org/2020/10/21/925832512/dark-archives-explores-the-use-of-human-skin-in-bookbinding', '', ''),
(356, '2023-11-06 12:20:07', '', 'https://web.archive.org/web/20230708143050/https://www.npr.org/2020/10/21/925832512/dark-archives-explores-the-use-of-human-skin-in-bookbinding', '', ''),
(357, '2023-11-06 12:20:07', '', '#cite_ref-cjal_25-0', '', ''),
(358, '2023-11-06 12:20:07', '', '#cite_ref-cjal_25-1', '', ''),
(359, '2023-11-06 12:20:07', '', '#cite_ref-cjal_25-2', '', ''),
(360, '2023-11-06 12:20:07', '', 'https://doi.org/10.33137%2Fcjalrcbu.v8.39216', '', ''),
(361, '2023-11-06 12:20:07', '', '/wiki/Doi_(identifier)', '', ''),
(362, '2023-11-06 12:20:07', '', 'https://doi.org/10.33137%2Fcjalrcbu.v8.39216', '', ''),
(363, '2023-11-06 12:20:07', '', '#cite_ref-cg_26-0', '', ''),
(364, '2023-11-06 12:20:07', '', '/wiki/Doi_(identifier)', '', ''),
(365, '2023-11-06 12:20:07', '', 'https://doi.org/10.1177%2F1474474020987252', '', ''),
(366, '2023-11-06 12:20:07', '', '/wiki/S2CID_(identifier)', '', ''),
(367, '2023-11-06 12:20:07', '', 'https://api.semanticscholar.org/CorpusID:234147497', '', ''),
(368, '2023-11-06 12:20:07', '', '#cite_ref-editor_27-0', '', ''),
(369, '2023-11-06 12:20:07', '', 'https://www.ala.org/news/member-news/2023/06/diane-dias-de-fazio-appointed-rbm-journal-rare-books-manuscripts-and-cultural', '', ''),
(370, '2023-11-06 12:20:07', '', 'https://web.archive.org/web/20230708134653/https://www.ala.org/news/member-news/2023/06/diane-dias-de-fazio-appointed-rbm-journal-rare-books-manuscripts-and-cultural', '', ''),
(371, '2023-11-06 12:20:07', '', '#cite_ref-theweek_28-0', '', ''),
(372, '2023-11-06 12:20:07', '', 'https://theweek.com/articles/936306/21-books-read-fall', '', ''),
(373, '2023-11-06 12:20:07', '', 'https://web.archive.org/web/20230708143051/https://theweek.com/articles/936306/21-books-read-fall', '', ''),
(374, '2023-11-06 12:20:07', '', '#cite_ref-wired_29-0', '', ''),
(375, '2023-11-06 12:20:07', '', 'https://www.wired.com/story/fall-2020-reading-list/', '', ''),
(376, '2023-11-06 12:20:07', '', 'https://web.archive.org/web/20230708143050/https://www.wired.com/story/fall-2020-reading-list/', '', ''),
(377, '2023-11-06 12:20:07', '', '#cite_ref-nyt2_30-0', '', ''),
(378, '2023-11-06 12:20:07', '', 'https://www.nytimes.com/2020/11/26/books/review/11-new-books-we-recommend-this-week.html', '', ''),
(379, '2023-11-06 12:20:07', '', 'https://web.archive.org/web/20230616000620/https://www.nytimes.com/2020/11/26/books/review/11-new-books-we-recommend-this-week.html', '', ''),
(380, '2023-11-06 12:20:07', '', '#cite_ref-lj_31-0', '', ''),
(381, '2023-11-06 12:20:07', '', 'https://www.libraryjournal.com/review/dark-archives', '', ''),
(382, '2023-11-06 12:20:07', '', 'https://web.archive.org/web/20230712215704/https://www.libraryjournal.com/review/dark-archives', '', ''),
(383, '2023-11-06 12:20:07', '', 'https://en.wikipedia.org/w/index.php?title=Dark_Archives&oldid=1183656472', '', ''),
(384, '2023-11-06 12:20:07', '', '/wiki/Help:Category', '', ''),
(385, '2023-11-06 12:20:07', '', '/wiki/Category:2020_non-fiction_books', '', ''),
(386, '2023-11-06 12:20:07', '', '/wiki/Category:Medical_ethics', '', ''),
(387, '2023-11-06 12:20:08', '', '/wiki/Category:Books_about_bibliophilia', '', ''),
(388, '2023-11-06 12:20:08', '', '/wiki/Category:Articles_with_short_description', '', ''),
(389, '2023-11-06 12:20:08', '', '/wiki/Category:Short_description_is_different_from_Wikidata', '', ''),
(390, '2023-11-06 12:20:08', '', '/wiki/Category:Featured_articles', '', ''),
(391, '2023-11-06 12:20:08', '', '//en.wikipedia.org/wiki/Wikipedia:Text_of_the_Creative_Commons_Attribution-ShareAlike_4.0_International_License', '', ''),
(392, '2023-11-06 12:20:08', '', '//en.wikipedia.org/wiki/Wikipedia:Text_of_the_Creative_Commons_Attribution-ShareAlike_4.0_International_License', '', ''),
(393, '2023-11-06 12:20:08', '', '//foundation.wikimedia.org/wiki/Terms_of_Use', '', ''),
(394, '2023-11-06 12:20:08', '', '//foundation.wikimedia.org/wiki/Privacy_policy', '', ''),
(395, '2023-11-06 12:20:08', '', '//www.wikimediafoundation.org/', '', ''),
(396, '2023-11-06 12:20:08', '', 'https://foundation.wikimedia.org/wiki/Special:MyLanguage/Policy:Privacy_policy', '', ''),
(397, '2023-11-06 12:20:08', '', '/wiki/Wikipedia:About', '', ''),
(398, '2023-11-06 12:20:08', '', '/wiki/Wikipedia:General_disclaimer', '', ''),
(399, '2023-11-06 12:20:08', '', '//en.wikipedia.org/wiki/Wikipedia:Contact_us', '', ''),
(400, '2023-11-06 12:20:08', '', 'https://foundation.wikimedia.org/wiki/Special:MyLanguage/Policy:Universal_Code_of_Conduct', '', ''),
(401, '2023-11-06 12:20:08', '', 'https://developer.wikimedia.org', '', ''),
(402, '2023-11-06 12:20:08', '', 'https://stats.wikimedia.org/#/en.wikipedia.org', '', ''),
(403, '2023-11-06 12:20:08', '', 'https://foundation.wikimedia.org/wiki/Special:MyLanguage/Policy:Cookie_statement', '', ''),
(404, '2023-11-06 12:20:08', '', '//en.m.wikipedia.org/w/index.php?title=Dark_Archives&mobileaction=toggle_view_mobile', '', ''),
(405, '2023-11-06 12:20:08', '', 'https://wikimediafoundation.org/', '', ''),
(406, '2023-11-06 12:20:08', '', 'https://www.mediawiki.org/', '', '');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `results`
--
ALTER TABLE `results`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `test`
--
ALTER TABLE `test`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `wiki_sections`
--
ALTER TABLE `wiki_sections`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `results`
--
ALTER TABLE `results`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `test`
--
ALTER TABLE `test`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `wiki_sections`
--
ALTER TABLE `wiki_sections`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=407;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
